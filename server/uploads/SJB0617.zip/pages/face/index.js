import { qryFaceVerifyStatus } from '../../apis/face-verify';
Page({
    /**
     * 页面的初始数据
     */
    data: {
        mchId: '',
        userIdKey: '',
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function ({ userIdKey, mchId }) {
        wx.hideHomeButton({
            success: (res) => {},
        });

        this.setData({
            userIdKey,
            mchId,
        });
    },
    onReady() {
        const { userIdKey } = this.data;
        if (userIdKey) {
            this.startFacialRecognitionVerify(userIdKey);
        }
    },

    startFacialRecognitionVerify(userIdKey) {
        wx.checkIsSupportFacialRecognition({
            checkAliveType: 2,
            success: () => {
                this.faceVerify(userIdKey);
            },
            fail: (err) => {
                // 不支持人脸
                wx.showModal({
                    content: '不支持人脸识别, 请升级微信版本',
                });
            },
        });
    },

    navigateToWebview(ret) {
        wx.redirectTo({
            url: `/pages/index/index?channel=face&faceVerifyRet=${ret}&mchId=${this.data.mchId}`,
        });
    },
    faceVerify(userIdKey) {
        wx.startFacialRecognitionVerify({
            checkAliveType: 2,
            userIdKey,
            success: async ({ verifyResult }) => {
                try {
                    await qryFaceVerifyStatus({
                        verifyResult,
                    });
                    this.navigateToWebview('success');
                } catch (error) {
                    wx.showToast({
                        title: '人脸核身失败',
                    });
                    this.navigateToWebview('fail');
                }
            },
            fail: (err) => {
                // 不支持人脸
                this.navigateToWebview('fail');
            },
        });
    },
});

import DOMAIN_CFG from '../../config/env.config';
import { getSessionToken } from '../../apis/getSessionToken';

Page({
  data: {
    src: DOMAIN_CFG.ONLINE_PATH + '?t=' + Date.now(),
  },
  onLoad(opts) {

    const { from, channel, page} = opts;
    // 从人脸识别页面过来
    if (channel === 'face') {
      return this.handleFaceVerify(opts);
    }

    // 从短信过来, 要跳转指定页面
    if (from === 'other' && page) {
      wx.setStorageSync('webview_page_url', page);
    } else {
      wx.setStorageSync('webview_page_url', '');
    }

    const code2SessionData = wx.getStorageSync('code2SessionData');
    if (code2SessionData) {
      this.setWebviewSrc(code2SessionData);
    } else {
      this.getSessionToken();
    }
  },
  getSessionToken() {
    wx.login({
      complete: (res) => {
        getSessionToken({
          code: res.code,
        }).then((code2SessionData) => {
          wx.setStorageSync('code2SessionData', code2SessionData);
          this.setWebviewSrc(code2SessionData);
        });
      },
    });
  },
  handleFaceVerify(opts) {
    const { faceVerifyRet, mchId } = opts;

    const redirectRoute = {
      fail: '#/mch-agreement',
      success: '#/sign-page',
    }[faceVerifyRet];
    this.setData({
      src: this.data.src + redirectRoute + `?mchId=${mchId}`,
    });
  },
  setWebviewSrc({ openId }) {
    const webviewPageUrl =  wx.getStorageSync('webview_page_url');
    const extraParams = webviewPageUrl ? `&webview_url=${webviewPageUrl}` : ''
    console.log(extraParams)
    this.setData({
      src: DOMAIN_CFG.ONLINE_PATH + `?opeid=${openId}${extraParams}&t=${Date.now()}`,
    });
  },
});

// 发布前修改对应的环境
import PA_ENV from './PA_ENV';

const API_PUBLIC_PATH = '/obp/mch/manage/center';
const API_PUBLIC_PATH_FAT2 = '/mch/manage/center';

const ORIGIN_CFG = {
    prd: {
        BASE_URL: 'https://openapi.pingan.com.cn' + API_PUBLIC_PATH, // axios基地址,
        ONLINE_PATH: 'https://b.pingan.com.cn/mid/midwebapp/index.html',
    },
    fat: {
        BASE_URL: 'https://openapi-test.pingan.com.cn' + API_PUBLIC_PATH,
        ONLINE_PATH: 'https://test-b-fat.pingan.com.cn/mid/midwebapp/index.html',
    },
    fat2: {
        BASE_URL: 'https://openapi-test.pingan.com.cn/obp-fat' + API_PUBLIC_PATH_FAT2,
        ONLINE_PATH: 'https://test-b-fat.pingan.com.cn/mid/midwebapp/fat2/test-env/index.html',
    },
    dev: {
        BASE_URL: 'https://test-b-dev.pingan.com.cn' + API_PUBLIC_PATH,
        ONLINE_PATH: 'https://test-b-fat.pingan.com.cn/mid/midwebapp/index.html',
    },
    uat: {
        BASE_URL: 'https://bbc-stg2.pingan.com.cn' + API_PUBLIC_PATH,
        ONLINE_PATH: 'https://test-b-uat.pingan.com.cn/mid/midwebapp/index.html',
    },
}[PA_ENV];

export default ORIGIN_CFG;

Page({
  data: {
    src: 'https://test-b-fat.pingan.com.cn/mid/midwebapp/index.html' + '?t=' + Date.now(),
  }
})

import env from '../config/env.config';

const request = (opts) => {
    return new Promise((resolve, reject) => {
        wx.request({
            url: env.BASE_URL + opts.url,
            method: opts.method,
            data: JSON.stringify(opts.data),
            header: {
                'Content-Type': 'application/json; charest=UTF-8',
                ...opts.header,
            },
            success(res) {
                let data = res.data;
                if (+data.responseCode === 0) {
                    resolve(data.data);
                } else {
                    reject(data);
                }
            },
            fail(err) {
                reject(err.data);
            },
        });
    });
};

export default request;

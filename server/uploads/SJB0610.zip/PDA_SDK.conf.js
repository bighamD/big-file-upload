module.exports = {
    app: {
        appName: '平安银行商家宝',
        appVersion: '1.0.3',
        appid: 'wx4a1a4e98529c0b34',
        defaultSharePage: 'pages/index/index',
        pageList: [
            {
                name: '首页',
                url: 'pages/index/index',
            },
        ],
    },
    param: {},
};

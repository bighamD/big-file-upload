const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

const { PA_ENV } = process.env;

fs.writeFileSync(path.resolve('./config/PA_ENV.js'), `export default ${JSON.stringify(PA_ENV)};`);

console.log(chalk.green('Current PA_ENV: ', PA_ENV.toUpperCase()));

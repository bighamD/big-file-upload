import DOMAIN_CFG from '../../config/env.config';
import { getSessionToken } from '../../apis/getSessionToken';

Page({
    data: {
        src: DOMAIN_CFG.ONLINE_PATH + '?t=' + Date.now(),
    },
    onLoad(opts) {
        if (opts.channel === 'face') {
            return this.handleFaceVerify(opts);
        }

        const code2SessionData = wx.getStorageSync('code2SessionData');
        if (code2SessionData) {
            this.setWebviewSrc(code2SessionData);
        } else {
            this.getSessionToken();
        }
    },
    getSessionToken() {
        wx.login({
            complete: (res) => {
                getSessionToken({
                    code: res.code,
                }).then((code2SessionData) => {
                    wx.setStorageSync('code2SessionData', code2SessionData);
                    this.setWebviewSrc(code2SessionData);
                });
            },
        });
    },
    handleFaceVerify(opts) {
        const { faceVerifyRet, mchId } = opts;
        const redirectRoute = {
            success: '#/mch-agreement',
            fail: '#/me',
        }[faceVerifyRet];

        this.setData({
            src: this.data.src + redirectRoute + `?mchId=${mchId}`,
        });
    },
    setWebviewSrc({ openId }) {
        this.setData({
            src: DOMAIN_CFG.ONLINE_PATH + `?openid=${openId}&t=${Date.now()}`,
        });
    },
});

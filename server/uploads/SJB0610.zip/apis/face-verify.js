import request from '../utils/request.js';

/**
 * 拿到人脸识别结果后台验证接口
 * @param {*} data
 */
export const qryFaceVerifyStatus = (opts) => {
    return request({
        url: '/weixin/getFaceInfo',
        method: 'POST',
        data: opts,
    });
};

import env from '../config/env.config';

const request = (opts) => {
    return new Promise((resolve, reject) => {
        wx.request({
            url: env.BASE_URL + opts.url,
            method: opts.method,
            data: JSON.stringify(opts.data),
            header: {
                'Content-Type': 'application/json; charest=UTF-8',
                ...opts.header
            },
            success (res) {
                resolve(res.data);
            },
            fail(err) {
                reject(err.data);
            }
        })
    })
}

export default request;
import request from '../utils/request.js';

/**
 * 获取openid接口
 * @param {*} data 
 */
export const getSessionToken = (data) => {
    return request({
        url: '/weixin/autologin',
        method: 'POST',
        data,
    });
}
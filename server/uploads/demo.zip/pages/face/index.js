// pages/face/index.js
import {qryFaceVerifyStatus} from '../../apis/face-verify';
let falg = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const {userIdKey, tokenId} = options;
    if (userIdKey && tokenId) {
      wx.checkIsSupportFacialRecognition({
        checkAliveType: 2,
        success: () => {
          this.faceVerify(userIdKey, tokenId);
        },
        fail: () => {
          // 不支持人脸
          wx.showModal({
            cancelColor: 'cancelColor',
          })
        }
      })
    }
  },
  navigateToWebview() {
    falg = (falg + 1) % 2;
    wx.redirectTo({
      url: `/pages/index/index?channel=face&faceVerifyRet=${falg}`,
    });
  },
  faceVerify(userIdKey, tokenId) {
    wx.startFacialRecognitionVerify({
      checkAliveType: 2,
      userIdKey,
      async success(res) {
        await qryFaceVerifyStatus({
          data: {
            verify_result: res.verify_result,
          },
          header: {
            tokenId,
          }
        });
        // success 去到电子签名页面
      }
    })
  },
})
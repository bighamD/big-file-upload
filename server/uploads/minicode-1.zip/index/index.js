Page({
  handleMsg(msg) {
    console.log(msg)
  }
})
